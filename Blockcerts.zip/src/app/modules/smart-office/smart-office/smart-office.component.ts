import { Component } from '@angular/core';

@Component({
  selector: 'app-smart-office',
  templateUrl: './smart-office.component.html',
  styleUrls: ['./smart-office.component.scss']
})
export class SmartOfficeComponent {

}
